package me.RockBed.bedcalculator.client;

import net.fabricmc.api.ClientModInitializer;

public class BedcalculatorClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
    }
}
